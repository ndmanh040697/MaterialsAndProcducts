
from flask import Blueprint, render_template, current_app
from ..models import db, Material, Product, BOMItem, Inventory
from ..services import units_producible_from_inventory

bp = Blueprint("projections", __name__, template_folder="../templates")

@bp.route("/")
def projection_page():
    rows = []
    q = db.session.query(BOMItem).join(Product).join(Material).all()
    threshold = current_app.config.get("MIN_UNITS_ALERT", 10)
    for bi in q:
        units = units_producible_from_inventory(bi.material_id, bi.qty_per_unit)
        rows.append({
            "material": bi.material.name,
            "material_uom": bi.material.uom,
            "inventory": (bi.material.inventory.qty_on_hand if hasattr(bi.material, "inventory") and bi.material.inventory else 0),
            "product": bi.product.name,
            "product_uom": bi.product.uom,
            "qty_per_unit": bi.qty_per_unit,
            "units_producible": units,
            "alert": units < threshold
        })
    return render_template("projections.html", rows=rows, threshold=threshold)
