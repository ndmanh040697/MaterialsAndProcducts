
from flask import Blueprint, render_template, request, redirect, url_for, flash
from .. import db
from ..models import Material, Inventory, MaterialTxn, get_or_create_inventory
from ..services import upsert_inventory
import pandas as pd
from datetime import datetime

bp = Blueprint("inventory", __name__, template_folder="../templates")

@bp.route("/")
def inv_page():
    inv_rows = db.session.query(Inventory).join(Material).order_by(Material.name).all()
    materials = Material.query.order_by(Material.name).all()
    return render_template("inventory.html", inventory=inv_rows, materials=materials)

@bp.route("/import", methods=["POST"])
def import_inventory():
    file = request.files.get("file")
    if not file:
        flash("Chưa chọn file.", "warning")
        return redirect(url_for("inventory.inv_page"))
    try:
        df = pd.read_excel(file)
        # Expected columns: material_name, uom, qty_on_hand
        for _, r in df.iterrows():
            name = str(r["material_name"]).strip()
            uom = str(r["uom"]).strip()
            qty = float(r["qty_on_hand"])
            m = Material.query.filter_by(name=name).first()
            if not m:
                m = Material(name=name, uom=uom)
                db.session.add(m)
                db.session.flush()
            inv = get_or_create_inventory(m.id)
            inv.qty_on_hand = qty
        db.session.commit()
        flash("Import tồn kho thành công!", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Lỗi import: {e}", "danger")
    return redirect(url_for("inventory.inv_page"))

@bp.route("/adjust", methods=["POST"])
def adjust():
    # Left pane: manual in/out with log
    material_id = int(request.form["material_id"])
    date_str = request.form.get("date")  # dd/mm/yy
    qty_in = float(request.form.get("qty_in") or 0)
    qty_out = float(request.form.get("qty_out") or 0)
    note = request.form.get("note", "")
    m = Material.query.get_or_404(material_id)
    # parse date
    if date_str:
        plan_dt = datetime.strptime(date_str, "%d/%m/%y")
    else:
        plan_dt = datetime.utcnow()
    delta = qty_in - qty_out
    upsert_inventory(material_id, delta, m.uom, note=note, ref_type="Manual")
    flash("Đã cập nhật xuất/nhập và lưu nhật ký.", "success")
    return redirect(url_for("inventory.inv_page"))
