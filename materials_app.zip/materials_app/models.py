
from datetime import datetime
from . import db

# --- Core master data ---
class Material(db.Model):
    __tablename__ = "materials"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    uom = db.Column(db.String(32), nullable=False)
    reorder_point = db.Column(db.Float, default=0.0)  # optional alert point

    def __repr__(self):
        return f"<Material {self.name}>"

class Product(db.Model):
    __tablename__ = "products"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    uom = db.Column(db.String(32), nullable=False)

    def __repr__(self):
        return f"<Product {self.name}>"

# --- BOM: Bill of Materials / Định mức ---
class BOMItem(db.Model):
    __tablename__ = "bom_items"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    material_id = db.Column(db.Integer, db.ForeignKey("materials.id"), nullable=False)
    qty_per_unit = db.Column(db.Float, nullable=False)  # định mức NVL cho 1 đơn vị SP
    # choice_group: các NVL thuộc cùng group là lựa chọn thay thế (chọn 1 trong nhiều)
    choice_group = db.Column(db.String(64), nullable=True)  # ví dụ: "CORE" => lõi A hoặc lõi B
    is_active = db.Column(db.Boolean, default=True)

    product = db.relationship("Product", backref=db.backref("bom_items", lazy="dynamic"))
    material = db.relationship("Material")

    def __repr__(self):
        return f"<BOMItem P{self.product_id} M{self.material_id} qty {self.qty_per_unit} group {self.choice_group}>"

# --- Inventory (current qty) ---
class Inventory(db.Model):
    __tablename__ = "inventory"
    material_id = db.Column(db.Integer, db.ForeignKey("materials.id"), primary_key=True)
    qty_on_hand = db.Column(db.Float, default=0.0, nullable=False)

    material = db.relationship("Material")

# --- Transaction log for stock movements ---
class MaterialTxn(db.Model):
    __tablename__ = "material_txns"
    id = db.Column(db.Integer, primary_key=True)
    ts = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    material_id = db.Column(db.Integer, db.ForeignKey("materials.id"), nullable=False)
    qty_in = db.Column(db.Float, default=0.0)
    qty_out = db.Column(db.Float, default=0.0)
    uom = db.Column(db.String(32), nullable=False)
    note = db.Column(db.String(255))
    ref_type = db.Column(db.String(50))  # e.g., "Manual", "Issue"
    ref_id = db.Column(db.Integer)       # reference to issue_header.id when ref_type == "Issue"

    material = db.relationship("Material")

# --- Issue materials for work orders (page 3) ---
class IssueHeader(db.Model):
    __tablename__ = "issue_headers"
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    plan_date = db.Column(db.Date)  # ngày nhập của user
    created_by = db.Column(db.String(80))

class IssueLine(db.Model):
    __tablename__ = "issue_lines"
    id = db.Column(db.Integer, primary_key=True)
    header_id = db.Column(db.Integer, db.ForeignKey("issue_headers.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    material_id = db.Column(db.Integer, db.ForeignKey("materials.id"), nullable=False)
    product_qty = db.Column(db.Float, nullable=False)   # số lượng SP cần SX cho dòng này
    qty = db.Column(db.Float, nullable=False)           # số lượng NVL xuất (đã tính từ BOM * product_qty, user có thể sửa)
    uom = db.Column(db.String(32), nullable=False)

    header = db.relationship("IssueHeader", backref=db.backref("lines", lazy="dynamic"))
    product = db.relationship("Product")
    material = db.relationship("Material")

# Convenience helpers
def get_or_create_inventory(material_id: int):
    inv = Inventory.query.get(material_id)
    if not inv:
        inv = Inventory(material_id=material_id, qty_on_hand=0.0)
        db.session.add(inv)
    return inv
